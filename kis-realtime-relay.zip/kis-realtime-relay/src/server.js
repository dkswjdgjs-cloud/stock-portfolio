// =============================================================
// GLOW 프론트엔드가 연결하는 웹소켓 서버
//
// 클라이언트 -> 서버 메시지:
//   {"type": "subscribe", "tickers": ["005930", "000660", ...]}  // 보유+즐겨찾기 (상시)
//   {"type": "watch", "ticker": "035720"}                         // 종목상세에서 보고있는 종목
//   {"type": "unwatch"}                                           // 종목상세 닫음
//
// 서버 -> 클라이언트 메시지:
//   {"type": "price", "ticker": "005930", "price": 70500,
//    "change": 500, "changeRate": 0.71, "time": "111500"}
//   {"type": "status", "kisConnected": true}
// =============================================================

const { WebSocketServer, WebSocket } = require('ws');
const { SubscriptionRegistry } = require('./subscriptions');

const PORT = Number(process.env.RELAY_PORT) || 8765;
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

function createClientServer(kisClient) {
  const wss = new WebSocketServer({
    port: PORT,
    verifyClient: (info) => {
      if (ALLOWED_ORIGINS.length === 0) return true;
      const origin = info.req.headers.origin;
      return !!origin && ALLOWED_ORIGINS.includes(origin);
    },
  });

  const registry = new SubscriptionRegistry();
  let nextClientId = 1;

  function syncKisSubscriptions() {
    kisClient.syncSubscriptions(registry.getUnion());
  }

  function broadcastStatus(kisConnected) {
    const msg = JSON.stringify({ type: 'status', kisConnected });
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) client.send(msg);
    }
  }

  kisClient.on('tick', (tick) => {
    const msg = JSON.stringify({
      type: 'price',
      ticker: tick.ticker,
      price: tick.price,
      change: tick.change,
      changeRate: tick.changeRate,
      time: tick.time,
    });
    for (const client of wss.clients) {
      if (client.readyState === WebSocket.OPEN) client.send(msg);
    }
  });

  kisClient.on('connected', () => broadcastStatus(true));
  kisClient.on('disconnected', () => broadcastStatus(false));

  wss.on('connection', (ws) => {
    const clientId = nextClientId++;
    console.log(`[server] 클라이언트 연결 (#${clientId}), 현재 접속자: ${wss.clients.size}`);

    ws.send(JSON.stringify({ type: 'status', kisConnected: kisClient.connected }));

    ws.on('message', (raw) => {
      let msg;
      try {
        msg = JSON.parse(raw.toString());
      } catch {
        return;
      }

      if (msg.type === 'subscribe' && Array.isArray(msg.tickers)) {
        registry.setAlways(clientId, msg.tickers.map(String));
        syncKisSubscriptions();
      } else if (msg.type === 'watch' && msg.ticker) {
        registry.setWatch(clientId, String(msg.ticker));
        syncKisSubscriptions();
      } else if (msg.type === 'unwatch') {
        registry.setWatch(clientId, null);
        syncKisSubscriptions();
      }
    });

    ws.on('close', () => {
      console.log(`[server] 클라이언트 연결 종료 (#${clientId})`);
      registry.removeClient(clientId);
      syncKisSubscriptions();
    });

    ws.on('error', (err) => {
      console.error(`[server] 클라이언트 에러 (#${clientId}):`, err.message);
    });
  });

  console.log(`[server] GLOW 클라이언트용 웹소켓 서버 시작 (port ${PORT})`);
  return wss;
}

module.exports = { createClientServer };
