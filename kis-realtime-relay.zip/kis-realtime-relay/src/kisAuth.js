// =============================================================
// KIS 실시간 웹소켓용 approval_key 발급/관리
// (REST API의 access_token과는 별도 — /oauth2/Approval 엔드포인트 사용)
// =============================================================

const KIS_REST_URL = process.env.KIS_REST_URL || 'https://openapi.koreainvestment.com:9443';
const KIS_APP_KEY = process.env.KIS_APP_KEY;
const KIS_APP_SECRET = process.env.KIS_APP_SECRET;

// approval_key는 발급 후 보통 24시간 정도 유효하다고 알려져 있음.
// 안전하게 12시간마다 갱신한다.
const REFRESH_INTERVAL_MS = 12 * 60 * 60 * 1000;

async function fetchApprovalKey() {
  if (!KIS_APP_KEY || !KIS_APP_SECRET) {
    throw new Error('KIS_APP_KEY / KIS_APP_SECRET 환경변수가 설정되지 않았습니다.');
  }

  const res = await fetch(`${KIS_REST_URL}/oauth2/Approval`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type: 'client_credentials',
      appkey: KIS_APP_KEY,
      secretkey: KIS_APP_SECRET,
    }),
  });

  const data = await res.json();
  if (!data.approval_key) {
    throw new Error(`approval_key 발급 실패: ${JSON.stringify(data)}`);
  }
  return data.approval_key;
}

/**
 * approval_key를 관리하는 객체를 만든다.
 * - get(): 현재 캐시된 키 반환 (없으면 발급)
 * - onRefresh(cb): 주기적으로 키가 갱신될 때 콜백 호출 (재연결 등에 사용)
 */
function createApprovalKeyManager() {
  let current = null;
  const refreshListeners = [];

  async function refresh() {
    const key = await fetchApprovalKey();
    const changed = key !== current;
    current = key;
    if (changed) {
      console.log('[kisAuth] approval_key 발급/갱신 완료');
      for (const cb of refreshListeners) cb(current);
    }
    return current;
  }

  async function get() {
    if (!current) await refresh();
    return current;
  }

  function onRefresh(cb) {
    refreshListeners.push(cb);
  }

  function startAutoRefresh() {
    setInterval(() => {
      refresh().catch((err) => console.error('[kisAuth] approval_key 갱신 실패:', err.message));
    }, REFRESH_INTERVAL_MS);
  }

  return { get, refresh, onRefresh, startAutoRefresh };
}

module.exports = { createApprovalKeyManager };
