// =============================================================
// 클라이언트(브라우저 탭)별 구독 상태 관리
// - always: 보유 + 즐겨찾기 종목 (클라이언트가 접속 시 보내줌)
// - watch: 현재 StockDetail에서 보고 있는 종목 (1개, 없으면 null)
// 전체 union을 계산해서 KIS 구독 목록과 동기화하는 데 사용한다.
// =============================================================

class SubscriptionRegistry {
  constructor() {
    this.always = new Map(); // clientId -> Set<ticker>
    this.watch = new Map();  // clientId -> ticker | null
  }

  setAlways(clientId, tickers) {
    this.always.set(clientId, new Set(tickers.filter(Boolean)));
  }

  setWatch(clientId, ticker) {
    if (ticker) this.watch.set(clientId, ticker);
    else this.watch.delete(clientId);
  }

  removeClient(clientId) {
    this.always.delete(clientId);
    this.watch.delete(clientId);
  }

  /** 현재 모든 클라이언트가 필요로 하는 종목코드 union */
  getUnion() {
    const union = new Set();
    for (const set of this.always.values()) {
      for (const t of set) union.add(t);
    }
    for (const t of this.watch.values()) {
      union.add(t);
    }
    return union;
  }
}

module.exports = { SubscriptionRegistry };
