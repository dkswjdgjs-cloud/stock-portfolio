// =============================================================
// KIS 웹소켓 실시간 메시지 파싱
//
// KIS 실시간 데이터는 두 가지 형태로 온다:
//  1) JSON 문자열 — PINGPONG, 구독 응답(SUBSCRIBE SUCCESS 등)
//  2) "0|H0STCNT0|001|필드1^필드2^필드3^..." 형태의 평문 — 실제 체결 데이터
//
// H0STCNT0(국내주식 실시간체결가) 필드 순서는 KIS Open API 문서 기준이며,
// 실제 운영 중 raw 메시지를 로그로 남기도록 했으니, 필드 위치가 안 맞으면
// 로그를 보고 FIELDS 배열 순서만 조정하면 된다.
// =============================================================

const TR_ID_DOMESTIC_PRICE = 'H0STCNT0';

// 앞에서부터 우리가 실제로 쓰는 핵심 필드만 이름 붙임 (나머지는 raw 배열에 보존)
const FIELDS = [
  'stockCode',     // 0  유가증권 단축 종목코드
  'tradeTime',     // 1  주식 체결 시간 (HHMMSS)
  'price',         // 2  주식 현재가
  'changeSign',    // 3  전일 대비 부호 (1:상한 2:상승 3:보합 4:하락 5:하한)
  'change',        // 4  전일 대비
  'changeRate',    // 5  전일 대비율 (%)
  'weightedAvg',   // 6  가중평균 주식가격
  'open',          // 7  시가
  'high',          // 8  고가
  'low',           // 9  저가
  'askPrice1',     // 10 매도호가1
  'bidPrice1',     // 11 매수호가1
  'tradeVolume',   // 12 체결 거래량
  'accVolume',     // 13 누적 거래량
  'accAmount',     // 14 누적 거래 금액
];

const SIGN_DIRECTION = {
  '1': 1,  // 상한
  '2': 1,  // 상승
  '3': 0,  // 보합
  '4': -1, // 하락
  '5': -1, // 하한
};

/**
 * 최상위 메시지 분기: JSON(PINGPONG/응답) 인지 실시간 데이터인지 구분.
 * 반환: { kind: 'json', data } | { kind: 'realtime', trId, count, ticks } | { kind: 'unknown', raw }
 */
function parseMessage(raw) {
  const trimmed = raw.trim();
  if (trimmed.startsWith('{')) {
    try {
      return { kind: 'json', data: JSON.parse(trimmed) };
    } catch {
      return { kind: 'unknown', raw };
    }
  }

  if (trimmed.startsWith('0|') || trimmed.startsWith('1|')) {
    const parts = trimmed.split('|');
    const [encryptFlag, trId, countStr, body] = parts;

    if (trId !== TR_ID_DOMESTIC_PRICE) {
      return { kind: 'realtime', trId, count: Number(countStr) || 0, ticks: [], encrypted: encryptFlag === '1' };
    }

    const count = Number(countStr) || 1;
    const fieldsPerRecord = FIELDS.length;
    const allFields = (body || '').split('^');

    const ticks = [];
    for (let i = 0; i < count; i++) {
      const slice = allFields.slice(i * fieldsPerRecord, (i + 1) * fieldsPerRecord);
      if (slice.length === 0) break;
      ticks.push(parseTick(slice, allFields));
    }

    return { kind: 'realtime', trId, count, ticks, encrypted: encryptFlag === '1' };
  }

  return { kind: 'unknown', raw };
}

function parseTick(slice, fullRawFields) {
  const tick = { raw: fullRawFields };
  FIELDS.forEach((name, idx) => {
    tick[name] = slice[idx];
  });

  const price = Number(tick.price);
  const change = Number(tick.change);
  const changeRate = Number(tick.changeRate);
  const direction = SIGN_DIRECTION[tick.changeSign] ?? 0;

  return {
    ticker: tick.stockCode,
    time: tick.tradeTime,
    price,
    change: direction < 0 ? -Math.abs(change) : Math.abs(change),
    changeRate: direction < 0 ? -Math.abs(changeRate) : Math.abs(changeRate),
    raw: tick.raw,
  };
}

// PINGPONG 메시지인지 확인 (header.tr_id === 'PINGPONG')
function isPingPong(jsonData) {
  return jsonData?.header?.tr_id === 'PINGPONG';
}

module.exports = { parseMessage, isPingPong, TR_ID_DOMESTIC_PRICE };
