// =============================================================
// KIS 실시간 웹소켓 클라이언트
// - approval_key로 연결
// - 종목 구독/해제 관리 (구독 목록을 들고 있다가 연결될 때마다 재전송)
// - PINGPONG 응답
// - 연결 끊기면 재연결 (backoff)
// - 체결 데이터를 'tick' 이벤트로 전달
// =============================================================

const { EventEmitter } = require('events');
const WebSocket = require('ws');
const { parseMessage, isPingPong, TR_ID_DOMESTIC_PRICE } = require('./parser');

const KIS_WS_URL = process.env.KIS_WS_URL || 'ws://ops.koreainvestment.com:21000';

const RECONNECT_BASE_DELAY_MS = 2000;
const RECONNECT_MAX_DELAY_MS = 60000;

class KisRealtimeClient extends EventEmitter {
  constructor(approvalKeyManager) {
    super();
    this.approvalKeyManager = approvalKeyManager;
    this.ws = null;
    this.subscribed = new Set(); // 현재 KIS에 구독 등록된 종목코드
    this.reconnectAttempts = 0;
    this.connected = false;

    // approval_key가 갱신되면 재연결 (새 키로 다시 인증해야 함)
    this.approvalKeyManager.onRefresh(() => {
      console.log('[kisClient] approval_key 갱신됨 — 재연결');
      this._reconnect();
    });
  }

  async start() {
    await this._connect();
  }

  async _connect() {
    const approvalKey = await this.approvalKeyManager.get();
    void approvalKey; // 연결 자체는 approval_key 없이도 가능, 구독 시에만 필요

    console.log(`[kisClient] KIS 웹소켓 연결 시도: ${KIS_WS_URL}`);
    this.ws = new WebSocket(KIS_WS_URL);

    this.ws.on('open', () => {
      console.log('[kisClient] KIS 웹소켓 연결됨');
      this.connected = true;
      this.reconnectAttempts = 0;
      // 기존 구독 목록을 새 연결에 재등록
      for (const ticker of this.subscribed) {
        this._sendSubscribe(ticker, '1');
      }
      this.emit('connected');
    });

    this.ws.on('message', (raw) => this._onMessage(raw.toString()));

    this.ws.on('close', (code, reason) => {
      console.warn(`[kisClient] KIS 웹소켓 종료 (code=${code}, reason=${reason})`);
      this.connected = false;
      this.emit('disconnected');
      this._scheduleReconnect();
    });

    this.ws.on('error', (err) => {
      console.error('[kisClient] KIS 웹소켓 에러:', err.message);
    });
  }

  _scheduleReconnect() {
    const delay = Math.min(
      RECONNECT_BASE_DELAY_MS * 2 ** this.reconnectAttempts,
      RECONNECT_MAX_DELAY_MS
    );
    this.reconnectAttempts += 1;
    console.log(`[kisClient] ${delay / 1000}초 후 재연결 시도`);
    setTimeout(() => {
      this._connect().catch((err) => console.error('[kisClient] 재연결 실패:', err.message));
    }, delay);
  }

  _reconnect() {
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
    }
  }

  async _onMessage(raw) {
    const parsed = parseMessage(raw);

    if (parsed.kind === 'json') {
      if (isPingPong(parsed.data)) {
        // KIS는 PINGPONG을 받은 그대로 echo 해주면 됨
        this.ws.send(raw);
        return;
      }
      // 구독 응답 등 — 디버깅용 로그만
      const rtCd = parsed.data?.body?.rt_cd;
      const msg1 = parsed.data?.body?.msg1;
      if (rtCd && rtCd !== '0') {
        console.warn('[kisClient] 구독 응답 오류:', JSON.stringify(parsed.data).slice(0, 300));
      } else if (msg1) {
        console.log('[kisClient] 응답:', msg1);
      }
      return;
    }

    if (parsed.kind === 'realtime' && parsed.trId === TR_ID_DOMESTIC_PRICE) {
      for (const tick of parsed.ticks) {
        this.emit('tick', tick);
      }
      return;
    }

    if (parsed.kind === 'unknown') {
      console.log('[kisClient] 알 수 없는 메시지:', raw.slice(0, 200));
    }
  }

  _sendSubscribe(ticker, trType) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    this.approvalKeyManager.get().then((approvalKey) => {
      const msg = {
        header: {
          approval_key: approvalKey,
          custtype: 'P',
          tr_type: trType, // '1' = 등록, '2' = 해제
          'content-type': 'utf-8',
        },
        body: {
          input: {
            tr_id: TR_ID_DOMESTIC_PRICE,
            tr_key: ticker,
          },
        },
      };
      this.ws.send(JSON.stringify(msg));
    });
  }

  /** 구독 목록을 targetTickers(Set<string>)로 동기화 — 새로 추가된 건 구독, 빠진 건 해제 */
  syncSubscriptions(targetTickers) {
    for (const ticker of targetTickers) {
      if (!this.subscribed.has(ticker)) {
        this.subscribed.add(ticker);
        console.log(`[kisClient] 구독 추가: ${ticker}`);
        this._sendSubscribe(ticker, '1');
      }
    }
    for (const ticker of [...this.subscribed]) {
      if (!targetTickers.has(ticker)) {
        this.subscribed.delete(ticker);
        console.log(`[kisClient] 구독 해제: ${ticker}`);
        this._sendSubscribe(ticker, '2');
      }
    }
  }
}

module.exports = { KisRealtimeClient };
