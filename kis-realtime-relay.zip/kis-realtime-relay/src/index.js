// =============================================================
// kis-realtime-relay 진입점
// =============================================================

require('dotenv').config();

const { createApprovalKeyManager } = require('./kisAuth');
const { KisRealtimeClient } = require('./kisClient');
const { createClientServer } = require('./server');

async function main() {
  const approvalKeyManager = createApprovalKeyManager();

  // 시작 시 approval_key 1회 발급 (실패하면 그대로 종료 — 설정 문제 즉시 확인 가능)
  await approvalKeyManager.get();
  approvalKeyManager.startAutoRefresh();

  const kisClient = new KisRealtimeClient(approvalKeyManager);
  await kisClient.start();

  createClientServer(kisClient);
}

main().catch((err) => {
  console.error('[index] 치명적 오류:', err);
  process.exit(1);
});
