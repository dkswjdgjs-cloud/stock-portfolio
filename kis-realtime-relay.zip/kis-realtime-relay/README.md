# kis-realtime-relay

KIS(한국투자증권) 실시간 웹소켓 시세를 받아서, GLOW 프론트엔드(브라우저)가 연결할 수 있는
자체 웹소켓 서버로 중계하는 작은 서비스입니다. Oracle Cloud 서버에서 Docker로 상시 실행됩니다.

## 왜 필요한가

- Vercel 서버리스 함수는 KIS 실시간 웹소켓처럼 "계속 열려있는 연결"을 유지할 수 없음
- 그래서 항상 켜져있는 Oracle 서버가 KIS와의 연결을 대신 들고 있다가, GLOW에는 가벼운 자체 웹소켓으로 다시 뿌려줌

## 구독 정책

- **항상 구독**: GLOW가 접속 시 보내주는 "보유 종목 + 즐겨찾기 종목" 목록 (`subscribe` 메시지)
- **동적 구독**: 종목 상세(StockDetail) 화면을 열면 그 종목 1개 추가 (`watch`), 닫으면 해제 (`unwatch`)

KIS 웹소켓은 연결당 동시 구독 가능한 종목 수에 제한이 있습니다(개인 계정 기준 보통 수십 개).
보유+즐겨찾기가 그 한도를 넘을 정도로 많아지면 `kisClient.js`의 `syncSubscriptions`에서
우선순위를 두고 제한하는 로직을 추가해야 합니다 (현재는 제한 없이 전부 구독).

## 1. 환경변수 설정

```bash
cd kis-realtime-relay
cp .env.example .env
```

`.env` 파일을 열어서 채워주세요:

- `KIS_APP_KEY`, `KIS_APP_SECRET` — Vercel에 등록된 것과 동일한 값
- `ALLOWED_ORIGINS` — GLOW 배포 주소 (예: `https://stock-portfolio-rho-ten.vercel.app`)
  - 비워두면 모든 origin 허용 (개발/테스트 시에만 권장)

## 2. 로컬(Codespaces)에서 먼저 테스트

배포 전에 Codespaces에서 한 번 직접 띄워서 KIS 연결이 되는지 확인하는 걸 추천합니다.

```bash
npm install
node src/index.js
```

정상이면 이런 로그가 보입니다:

```
[kisAuth] approval_key 발급/갱신 완료
[kisClient] KIS 웹소켓 연결 시도: ws://ops.koreainvestment.com:21000
[kisClient] KIS 웹소켓 연결됨
[server] GLOW 클라이언트용 웹소켓 서버 시작 (port 8765)
```

다른 터미널을 열어서 테스트 클라이언트로 접속 + 종목 구독:

```bash
npx wscat -c ws://localhost:8765
```

접속 후:
```
{"type":"subscribe","tickers":["005930"]}
```

장중이라면 잠시 후 `{"type":"price","ticker":"005930",...}` 메시지가 들어오는지 확인하세요.

### ⚠️ 필드 위치가 안 맞을 경우

`H0STCNT0`의 필드 순서는 KIS 문서 기준으로 작성했지만, 실제 응답과 다를 수 있습니다.
받은 가격(`price`)이나 등락률(`changeRate`)이 이상하면:

1. `src/kisClient.js`의 `_onMessage`에서 `parsed.kind === 'realtime'`일 때 raw 메시지를 그대로
   `console.log`로 남기도록 임시로 추가
2. 실제 메시지의 `^`로 구분된 필드들을 순서대로 보고
3. `src/parser.js`의 `FIELDS` 배열 순서를 실제와 맞게 조정

(0~5번 필드: 종목코드/체결시간/현재가/대비부호/대비/대비율 — 이 6개가 가장 중요합니다)

## 3. Oracle 서버에 배포

기존 OpenProject/Nextcloud와 같은 방식(Docker Compose)으로 추가합니다.

1. 이 `kis-realtime-relay` 폴더 전체를 서버에 복사 (git clone 또는 scp)
2. `.env` 파일 작성 (위 1번과 동일, 서버에서 직접 작성 — git에 커밋하지 말 것)
3. `docker-compose.snippet.yml` 내용을 기존 `docker-compose.yml`의 `services:` 아래에 추가
4. `docker compose up -d --build kis-realtime-relay`
5. `docker compose logs -f kis-realtime-relay` 로 연결 확인

## 4. 외부 노출 (wss://realtime.segirnd.uk)

브라우저(GLOW)에서 `wss://`로 접속하려면 TLS가 필요합니다. 두 가지 방법 중 편한 걸 선택하세요.

### 방법 A: 기존 reverse proxy에 location 추가 (nginx 예시)

```nginx
server {
    listen 443 ssl;
    server_name realtime.segirnd.uk;

    # 기존 인증서 설정 재사용 또는 certbot으로 신규 발급

    location / {
        proxy_pass http://127.0.0.1:8765;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

### 방법 B: Caddy (자동 TLS, 더 간단)

```
realtime.segirnd.uk {
    reverse_proxy 127.0.0.1:8765
}
```

둘 중 어떤 reverse proxy를 이미 쓰고 계신지에 따라 골라주시면 됩니다. Cloudflare DNS는
이 서브도메인에 대해 "DNS only"(회색 구름)로 두고, TLS는 서버에서 직접 처리하는 걸 권장합니다
(Cloudflare 프록시는 표준 포트가 아닌 포트에 대해 웹소켓을 지원하지 않을 수 있음 —
443으로 받아서 내부에서 8765로 넘기면 문제 없음).

## 5. 프론트엔드(GLOW) 연동 — 다음 단계

이 relay가 정상 동작 확인되면, GLOW(Next.js) 쪽에 웹소켓 클라이언트를 붙이는 작업을 진행합니다:

- `wss://realtime.segirnd.uk` 접속
- 접속 시 보유+즐겨찾기 종목코드로 `subscribe` 전송
- StockDetail 진입/이탈 시 `watch`/`unwatch` 전송
- `price` 메시지 수신 시 사이드바/상세화면의 가격·등락 표시를 실시간 갱신
